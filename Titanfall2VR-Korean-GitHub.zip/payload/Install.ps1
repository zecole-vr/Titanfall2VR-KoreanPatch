﻿param(
 [ValidateSet('Install','Restore')][string]$Action='Install',
 [string]$GameRoot='C:\Program Files\EA Games\Titanfall2'
)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
try {
 if(Get-Process Titanfall2,Titanfall2VRLauncher -ErrorAction SilentlyContinue){throw '설치 또는 복구 전에 타이탄폴 2를 종료해 주세요.'}
 $gamePath=(Resolve-Path -LiteralPath $GameRoot).Path
 if(-not(Test-Path -LiteralPath (Join-Path $gamePath 'Titanfall2VRLauncher.exe'))){throw 'VR 모드를 먼저 설치해 주세요.'}
 $record=Get-Content -Raw -LiteralPath (Join-Path $gamePath '.circuitlord-vr-mods\Titanfall2VR.json') | ConvertFrom-Json
 if(@('1.0.10','1.0.11') -notcontains $record.version -or $record.northstarVersion -ne '1.31.13'){throw '이 패치는 TF2VR 1.0.10/1.0.11 및 Northstar 1.31.13을 지원합니다. 설치된 VR 모드 버전을 확인해 주세요.'}
 $profileRoot=(Resolve-Path -LiteralPath (Join-Path $gamePath 'TF2VR')).Path
 $modPath=[IO.Path]::GetFullPath((Join-Path $profileRoot 'mods\Korean.MenuTest'))
 $pluginPath=[IO.Path]::GetFullPath((Join-Path $profileRoot 'plugins\Korean.CaptionLayout.dll'))
 $startupPath=Join-Path $profileRoot 'mods\Titanfall2VR.Cockpit\mod\resource\tf2vr\startup\text.r8'
 $startupOriginal=Join-Path $profileRoot 'korean-menu-backups\startup-text-original.r8'
 $startupManifest=Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'VRStartup\manifest.json')|ConvertFrom-Json
 $startupHash=(Get-FileHash -LiteralPath $startupPath -Algorithm SHA256).Hash
 if($startupHash -ne $startupManifest.original_sha256 -and $startupHash -ne $startupManifest.translated_sha256){throw '지원하는 원본과 다른 VR 시작 안내 파일입니다. 설치를 중단했습니다.'}
 if(Test-Path -LiteralPath $startupOriginal){
  if((Get-FileHash -LiteralPath $startupOriginal -Algorithm SHA256).Hash -ne $startupManifest.original_sha256){throw 'VR 시작 안내 원본 백업의 검증에 실패했습니다.'}
 }elseif($startupHash -ne $startupManifest.original_sha256){throw 'VR 시작 안내의 원본 백업을 찾을 수 없습니다.'}
 foreach($target in @($modPath,$pluginPath)){if(-not $target.StartsWith($profileRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw '설치 대상 경로가 올바르지 않습니다.'}}
 if(Test-Path -LiteralPath $modPath){$existing=Get-Content -Raw -LiteralPath (Join-Path $modPath 'mod.json')|ConvertFrom-Json;if($existing.Name -ne 'Korean.MenuTest'){throw '설치 위치에 다른 모드가 있습니다.'}}
 $stage=$null
 if($Action -eq 'Install') {
  $inventory=Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'package-hashes.json')|ConvertFrom-Json
  foreach($entry in $inventory.PSObject.Properties){
   $source=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot $entry.Name))
   if(-not $source.StartsWith($PSScriptRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw '설치 파일 경로가 올바르지 않습니다.'}
   if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $entry.Value){throw ('설치 파일 검증 실패: '+$entry.Name)}
  }
  $sourceManifest=Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'Korean.MenuTest\mod.json')|ConvertFrom-Json
  if($sourceManifest.Name -ne 'Korean.MenuTest'){throw '한글패치 정보가 올바르지 않습니다.'}
  $stage=Join-Path $profileRoot ('korean-menu-staging-'+[Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $stage | Out-Null
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Korean.MenuTest') -Destination $stage -Recurse
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Korean.CaptionLayout.dll') -Destination $stage
 }
 $backup=Join-Path $profileRoot ('korean-menu-backups\v029-'+[Guid]::NewGuid().ToString('N'))
 New-Item -ItemType Directory -Path $backup -Force | Out-Null
 Copy-Item -LiteralPath $startupPath -Destination (Join-Path $backup 'startup-text-before.r8')
 if(-not(Test-Path -LiteralPath $startupOriginal)){Copy-Item -LiteralPath $startupPath -Destination $startupOriginal}
 $enabledPath=Join-Path $profileRoot 'enabledmods.json'
 if(Test-Path -LiteralPath $enabledPath){Copy-Item -LiteralPath $enabledPath -Destination $backup}
 $modMoved=$false;$pluginMoved=$false;$newMod=$false;$newPlugin=$false;$startupChanged=$false
 try {
  if(Test-Path -LiteralPath $modPath){[IO.Directory]::Move($modPath,(Join-Path $backup 'Korean.MenuTest'));$modMoved=$true}
  if(Test-Path -LiteralPath $pluginPath){[IO.File]::Move($pluginPath,(Join-Path $backup 'Korean.CaptionLayout.dll'));$pluginMoved=$true}
  if($Action -eq 'Install'){
   New-Item -ItemType Directory -Force -Path (Split-Path -Parent $pluginPath)|Out-Null
   [IO.Directory]::Move((Join-Path $stage 'Korean.MenuTest'),$modPath);$newMod=$true
   [IO.File]::Move((Join-Path $stage 'Korean.CaptionLayout.dll'),$pluginPath);$newPlugin=$true
   if(Test-Path -LiteralPath $enabledPath){
    $enabled=Get-Content -Raw -LiteralPath $enabledPath|ConvertFrom-Json
    if(-not $enabled.PSObject.Properties['Korean.MenuTest']){$enabled|Add-Member -NotePropertyName 'Korean.MenuTest' -NotePropertyValue ([PSCustomObject]@{})}
    $enabled.'Korean.MenuTest'|Add-Member -NotePropertyName $sourceManifest.Version -NotePropertyValue $true -Force
    $enabled|ConvertTo-Json -Depth 10|Set-Content -LiteralPath $enabledPath -Encoding UTF8
   }
  }
  $startupChanged=$true
  if($Action -eq 'Install'){$startupSource=Join-Path $PSScriptRoot 'VRStartup\text.r8';$expectedStartup=$startupManifest.translated_sha256}
  else {$startupSource=$startupOriginal;$expectedStartup=$startupManifest.original_sha256}
  Copy-Item -LiteralPath $startupSource -Destination $startupPath -Force
  if((Get-FileHash -LiteralPath $startupPath -Algorithm SHA256).Hash -ne $expectedStartup){throw 'VR 시작 안내 파일의 복사 검증에 실패했습니다.'}
 } catch {
  if($startupChanged){Copy-Item -LiteralPath (Join-Path $backup 'startup-text-before.r8') -Destination $startupPath -Force}
  if($newMod){[IO.Directory]::Move($modPath,(Join-Path $stage 'Korean.MenuTest'))}
  if($newPlugin){[IO.File]::Move($pluginPath,(Join-Path $stage 'Korean.CaptionLayout.dll'))}
  if($modMoved){[IO.Directory]::Move((Join-Path $backup 'Korean.MenuTest'),$modPath)}
  if($pluginMoved){[IO.File]::Move((Join-Path $backup 'Korean.CaptionLayout.dll'),$pluginPath)}
  if(Test-Path -LiteralPath (Join-Path $backup 'enabledmods.json')){Copy-Item -LiteralPath (Join-Path $backup 'enabledmods.json') -Destination $enabledPath -Force}
  throw
 }
 Write-Output ('기존 파일 백업 위치: '+$backup)
 if($Action -eq 'Install'){Write-Output '한글패치 설치가 완료되었습니다. VR 모드 설치기에서 게임을 실행하세요.'}
 else {Write-Output '한글패치를 제거하고 VR 시작 안내를 원본으로 복구했습니다.'}
}catch{Write-Host $_.Exception.Message -ForegroundColor Red;exit 1}
