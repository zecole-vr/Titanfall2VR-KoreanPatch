﻿param(
 [ValidateSet('Install','Restore')][string]$Action='Install',
 [string]$GameRoot='C:\Program Files\EA Games\Titanfall2'
)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
try {
 if(Get-Process Titanfall2,Titanfall2VRLauncher -ErrorAction SilentlyContinue){throw '설치 또는 복구 전에 타이탄폴 2를 종료해 주세요.'}
 $gamePath=(Resolve-Path -LiteralPath $GameRoot).Path
 if(-not(Test-Path -LiteralPath (Join-Path $gamePath 'Titanfall2VRLauncher.exe'))){throw 'VR 모드를 먼저 설치해 주세요.'}
 $record=Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $gamePath '.circuitlord-vr-mods\Titanfall2VR.json') | ConvertFrom-Json
 $profileRoot=(Resolve-Path -LiteralPath (Join-Path $gamePath 'TF2VR')).Path
 $modPath=[IO.Path]::GetFullPath((Join-Path $profileRoot 'mods\Korean.MenuTest'))
 $pluginPath=[IO.Path]::GetFullPath((Join-Path $profileRoot 'plugins\Korean.CaptionLayout.dll'))
 $startupPath=Join-Path $profileRoot 'mods\Titanfall2VR.Cockpit\mod\resource\tf2vr\startup\text.r8'
 $startupOriginal=Join-Path $profileRoot 'korean-menu-backups\startup-text-original.r8'
 $startupManifest=Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $PSScriptRoot 'VRStartup\manifest.json')|ConvertFrom-Json
 $startupHash=if(Test-Path -LiteralPath $startupPath){(Get-FileHash -LiteralPath $startupPath -Algorithm SHA256).Hash}else{''}
 $validBackup=(Test-Path -LiteralPath $startupOriginal) -and ((Get-FileHash -LiteralPath $startupOriginal -Algorithm SHA256).Hash -eq $startupManifest.original_sha256)
 $replaceStartup=($Action -eq 'Install' -and $startupHash -eq $startupManifest.original_sha256) -or ($startupHash -eq $startupManifest.translated_sha256 -and $validBackup)
 if(-not $replaceStartup){Write-Output '시작 안내 파일은 현재 VR 모드의 파일을 유지합니다.'}
 foreach($target in @($modPath,$pluginPath)){if(-not $target.StartsWith($profileRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw '설치 대상 경로가 올바르지 않습니다.'}}
 if(Test-Path -LiteralPath $modPath){$existing=Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $modPath 'mod.json')|ConvertFrom-Json;if($existing.Name -ne 'Korean.MenuTest'){throw '설치 위치에 다른 모드가 있습니다.'}}
 $stage=$null
 if($Action -eq 'Install') {
  $inventory=Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $PSScriptRoot 'package-hashes.json')|ConvertFrom-Json
  foreach($entry in $inventory.PSObject.Properties){
   $source=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot $entry.Name))
   if(-not $source.StartsWith($PSScriptRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw '설치 파일 경로가 올바르지 않습니다.'}
   if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $entry.Value){throw ('설치 파일 검증 실패: '+$entry.Name)}
  }
  $sourceManifest=Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $PSScriptRoot 'Korean.MenuTest\mod.json')|ConvertFrom-Json
  if($sourceManifest.Name -ne 'Korean.MenuTest'){throw '한글패치 정보가 올바르지 않습니다.'}
  $stage=Join-Path $profileRoot ('korean-menu-staging-'+[Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $stage | Out-Null
  $integration=Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $PSScriptRoot 'integration-baseline.json')|ConvertFrom-Json
  function MatchesBaseline($path,$hash){return (Test-Path -LiteralPath $path) -and (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -eq $hash}
  $northstarKnown=MatchesBaseline (Join-Path $profileRoot 'Northstar.dll') $integration.'Northstar.dll'
  $vrKnown=MatchesBaseline (Join-Path $profileRoot 'plugins/Titanfall2VR.dll') $integration.'plugins/Titanfall2VR.dll'
  $menuKnown=$northstarKnown -and $vrKnown
  foreach($rel in @('scripts/vscripts/tf2vr_menu.nut','resource/ui/menus/ingame_sp.menu')){
   if(-not(MatchesBaseline (Join-Path $profileRoot ('mods/Titanfall2VR.Cockpit/mod/'+$rel)) $integration.cockpit.$rel)){$menuKnown=$false}
  }
  $skipped=@()
  $sourceMod=Join-Path $PSScriptRoot 'Korean.MenuTest'
  $stagedMod=Join-Path $stage 'Korean.MenuTest'
  foreach($file in Get-ChildItem -LiteralPath $sourceMod -Recurse -File){
   $rel=$file.FullName.Substring($sourceMod.Length+1).Replace('\','/')
   if(($rel.StartsWith('mod/scripts/') -and $rel -ne 'mod/scripts/vscripts/korean_menu_test.nut') -or $rel.StartsWith('mod/resource/ui/')){
    $upstreamRel=$rel.Substring(4)
    $upstream=Join-Path $profileRoot ('mods/Titanfall2VR.Cockpit/mod/'+$upstreamRel)
    $entry=$integration.cockpit.PSObject.Properties[$upstreamRel]
    $keep=$northstarKnown
    if($entry){$keep=$keep -and (MatchesBaseline $upstream $entry.Value)}
    elseif(Test-Path -LiteralPath $upstream){$keep=$false}
    if($upstreamRel -in @('scripts/vscripts/tf2vr_menu.nut','resource/ui/menus/ingame_sp.menu')){$keep=$keep -and $menuKnown}
    if(-not $keep){$skipped+=$rel;continue}
   }
   $destination=Join-Path $stagedMod $rel
   New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination)|Out-Null
   Copy-Item -LiteralPath $file.FullName -Destination $destination
  }
  if($northstarKnown){Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Korean.CaptionLayout.dll') -Destination $stage}
  Write-Output ('변경된 원본으로 인해 제외한 번역 파일: '+$skipped.Count)
  foreach($rel in $skipped){Write-Output ('  '+$rel)}
 }
 $backup=Join-Path $profileRoot ('korean-menu-backups\v0220-'+[Guid]::NewGuid().ToString('N'))
 New-Item -ItemType Directory -Path $backup -Force | Out-Null
 if($replaceStartup){Copy-Item -LiteralPath $startupPath -Destination (Join-Path $backup 'startup-text-before.r8')}
 if($replaceStartup -and $startupHash -eq $startupManifest.original_sha256){
  if(Test-Path -LiteralPath $startupOriginal){Copy-Item -LiteralPath $startupOriginal -Destination (Join-Path $backup 'previous-startup-backup.r8')}
  Copy-Item -LiteralPath $startupPath -Destination $startupOriginal -Force
 }
 $enabledPath=Join-Path $profileRoot 'enabledmods.json'
 if(Test-Path -LiteralPath $enabledPath){Copy-Item -LiteralPath $enabledPath -Destination $backup}
 $modMoved=$false;$pluginMoved=$false;$newMod=$false;$newPlugin=$false;$startupChanged=$false
 try {
  if(Test-Path -LiteralPath $modPath){[IO.Directory]::Move($modPath,(Join-Path $backup 'Korean.MenuTest'));$modMoved=$true}
  if(Test-Path -LiteralPath $pluginPath){[IO.File]::Move($pluginPath,(Join-Path $backup 'Korean.CaptionLayout.dll'));$pluginMoved=$true}
  if($Action -eq 'Install'){
   New-Item -ItemType Directory -Force -Path (Split-Path -Parent $pluginPath)|Out-Null
   [IO.Directory]::Move((Join-Path $stage 'Korean.MenuTest'),$modPath);$newMod=$true
   if($northstarKnown){[IO.File]::Move((Join-Path $stage 'Korean.CaptionLayout.dll'),$pluginPath);$newPlugin=$true}
   if(Test-Path -LiteralPath $enabledPath){
    $enabled=Get-Content -Raw -Encoding UTF8 -LiteralPath $enabledPath|ConvertFrom-Json
    if(-not $enabled.PSObject.Properties['Korean.MenuTest']){$enabled|Add-Member -NotePropertyName 'Korean.MenuTest' -NotePropertyValue ([PSCustomObject]@{})}
    $enabled.'Korean.MenuTest'|Add-Member -NotePropertyName $sourceManifest.Version -NotePropertyValue $true -Force
    [IO.File]::WriteAllText($enabledPath,($enabled|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
   }
  }
  if($replaceStartup){
  $startupChanged=$true
  if($Action -eq 'Install'){$startupSource=Join-Path $PSScriptRoot 'VRStartup\text.r8';$expectedStartup=$startupManifest.translated_sha256}
  else {$startupSource=$startupOriginal;$expectedStartup=$startupManifest.original_sha256}
  Copy-Item -LiteralPath $startupSource -Destination $startupPath -Force
  if((Get-FileHash -LiteralPath $startupPath -Algorithm SHA256).Hash -ne $expectedStartup){throw 'VR 시작 안내 파일의 복사 검증에 실패했습니다.'}
  }
 } catch {
  if($startupChanged){Copy-Item -LiteralPath (Join-Path $backup 'startup-text-before.r8') -Destination $startupPath -Force}
  if($newMod){[IO.Directory]::Move($modPath,(Join-Path $stage 'Korean.MenuTest'))}
  if($newPlugin){[IO.File]::Move($pluginPath,(Join-Path $stage 'Korean.CaptionLayout.dll'))}
  if($modMoved){[IO.Directory]::Move((Join-Path $backup 'Korean.MenuTest'),$modPath)}
  if($pluginMoved){[IO.File]::Move((Join-Path $backup 'Korean.CaptionLayout.dll'),$pluginPath)}
  if(Test-Path -LiteralPath (Join-Path $backup 'enabledmods.json')){Copy-Item -LiteralPath (Join-Path $backup 'enabledmods.json') -Destination $enabledPath -Force}
  throw
 }
 Write-Output ('기존 파일 백업 위치: '+$backup)
 if($Action -eq 'Install'){Write-Output '한글패치 설치가 완료되었습니다. VR 모드 설치기에서 게임을 실행하세요.'}
 else {Write-Output '한글패치를 제거했습니다. 확인 가능한 시작 안내만 원본으로 복구했습니다.'}
}catch{Write-Host $_.Exception.Message -ForegroundColor Red;exit 1}
