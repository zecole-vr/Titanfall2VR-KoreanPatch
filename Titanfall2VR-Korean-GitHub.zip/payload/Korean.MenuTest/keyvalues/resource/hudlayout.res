"Resource/HudLayout.res"
{
 HudCloseCaptionSPPositioningProxy
 {
  xpos c-540
  ypos 680 [$WIN32]
  wide 1080
  tall 310 [$WIN32]
 }
 HudCloseCaptionMPPositioningProxy
 {
  xpos c-540
  ypos 680 [$WIN32]
  wide 1080
  tall 310 [$WIN32]
 }
}

