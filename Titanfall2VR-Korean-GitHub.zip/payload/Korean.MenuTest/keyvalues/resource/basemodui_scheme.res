Scheme
{
 Fonts
 {
 CloseCaption_Normal
 {
 1
 {
 name Default
 tall 40
 weight 500
 antialias 1
 }
 }
 CloseCaption_Italic
 {
 1
 {
 name Default
 tall 40
 weight 500
 antialias 1
 }
 }
 CloseCaption_Bold
 {
 1
 {
 name DefaultBold
 tall 40
 weight 900
 antialias 1
 }
 }
 CloseCaption_BoldItalic
 {
 1
 {
 name DefaultBold
 tall 40
 weight 900
 antialias 1
 }
 }
 KO_ComboMeasure
 {
 isproportional only
 1
 {
 name Default
 tall 32
 antialias 1
 }
 }
 }
 InheritableProperties
 {
 ComboButtonLarge
 {
 font KO_ComboMeasure [!$JAPANESE && !$TCHINESE]
 }
 }
}
