global function KoreanMenuTest_Init
void function KoreanMenuTest_Init()
{
    ClientCommand( "cc_rui 0" )
    ClientCommand( "cc_lang korean" )
    ClientCommand( "closecaption 1" )
    print( "[KO_TEST] IBM Plex Sans KR font / Korean caption VPK requested" )
}
