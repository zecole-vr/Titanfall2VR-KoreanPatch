﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Zecole.TitanfallKorean
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            if (args.Length == 2 && args[0] == "--verify-package")
            {
                try { ExtractPayload(args[1]); return 0; }
                catch (Exception ex) { File.WriteAllText(args[1] + ".error.txt", ex.ToString()); return 1; }
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            var form = new InstallerForm();
            if (args.Length == 3 && args[0] == "--apply" && (args[1] == "Install" || args[1] == "Restore"))
                form.Shown += async delegate { await form.Apply(args[1], args[2]); };
            Application.Run(form);
            return 0;
        }

        internal static void ExtractPayload(string destination)
        {
            if (Directory.Exists(destination)) throw new IOException("임시 폴더가 이미 존재합니다.");
            Directory.CreateDirectory(destination);
            string root = Path.GetFullPath(destination).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
            using (var zip = new ZipArchive(stream, ZipArchiveMode.Read))
            {
                foreach (var entry in zip.Entries)
                {
                    string path = Path.GetFullPath(Path.Combine(root, entry.FullName.Replace('/', Path.DirectorySeparatorChar)));
                    if (!path.StartsWith(root, StringComparison.OrdinalIgnoreCase)) throw new IOException("잘못된 설치 파일 경로입니다.");
                    if (entry.Name.Length == 0) { Directory.CreateDirectory(path); continue; }
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    entry.ExtractToFile(path, false);
                }
            }
            var hashes = new JavaScriptSerializer().Deserialize<Dictionary<string, string>>(File.ReadAllText(Path.Combine(root, "package-hashes.json")));
            using (var sha = SHA256.Create())
            {
                foreach (var pair in hashes)
                {
                    string path = Path.GetFullPath(Path.Combine(root, pair.Key.Replace('/', Path.DirectorySeparatorChar)));
                    if (!path.StartsWith(root, StringComparison.OrdinalIgnoreCase)) throw new IOException("잘못된 검증 경로입니다.");
                    using (var input = File.OpenRead(path))
                    {
                        string actual = BitConverter.ToString(sha.ComputeHash(input)).Replace("-", "");
                        if (!actual.Equals(pair.Value, StringComparison.OrdinalIgnoreCase)) throw new IOException("설치 파일 검증에 실패했습니다: " + pair.Key);
                    }
                }
            }
        }

        internal static bool IsGame(string path)
        {
            return !String.IsNullOrWhiteSpace(path) && File.Exists(Path.Combine(path, "Titanfall2.exe"));
        }

        internal static List<string> FindGames()
        {
            var candidates = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            Action<string> add = delegate(string path) {
                try { if (IsGame(path)) candidates.Add(Path.GetFullPath(path).TrimEnd('\\')); } catch { }
            };
            add(AppDomain.CurrentDomain.BaseDirectory);
            foreach (RegistryView view in new[] { RegistryView.Registry64, RegistryView.Registry32 })
            foreach (RegistryHive hive in new[] { RegistryHive.LocalMachine, RegistryHive.CurrentUser })
            {
                try
                {
                    using (var reg = RegistryKey.OpenBaseKey(hive, view))
                    {
                        using (var game = reg.OpenSubKey(@"SOFTWARE\Respawn\Titanfall2"))
                            if (game != null) add(game.GetValue("Install Dir") as string);
                        using (var uninstall = reg.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"))
                        {
                            if (uninstall != null) foreach (string name in uninstall.GetSubKeyNames())
                            using (var item = uninstall.OpenSubKey(name))
                            {
                                if (item == null) continue;
                                string title = item.GetValue("DisplayName") as string;
                                if (title != null && title.IndexOf("Titanfall", StringComparison.OrdinalIgnoreCase) >= 0)
                                    add(item.GetValue("InstallLocation") as string);
                            }
                        }
                        using (var steam = reg.OpenSubKey(@"SOFTWARE\Valve\Steam"))
                        {
                            if (steam == null) continue;
                            string path = (steam.GetValue("SteamPath") ?? steam.GetValue("InstallPath")) as string;
                            AddSteamLibrary(path, add);
                            if (String.IsNullOrWhiteSpace(path)) continue;
                            string libraries = Path.Combine(path, @"steamapps\libraryfolders.vdf");
                            if (File.Exists(libraries)) foreach (Match m in Regex.Matches(File.ReadAllText(libraries), "\"path\"\\s+\"([^\"]+)\""))
                                AddSteamLibrary(m.Groups[1].Value.Replace(@"\\", @"\"), add);
                        }
                    }
                }
                catch { }
            }
            foreach (DriveInfo drive in DriveInfo.GetDrives())
            {
                if (drive.DriveType != DriveType.Fixed || !drive.IsReady) continue;
                foreach (string relative in new[] { @"Program Files\EA Games\Titanfall2", @"Program Files (x86)\Origin Games\Titanfall2", @"EA Games\Titanfall2", @"SteamLibrary\steamapps\common\Titanfall2", @"Program Files (x86)\Steam\steamapps\common\Titanfall2" })
                    add(Path.Combine(drive.RootDirectory.FullName, relative));
            }
            return new List<string>(candidates);
        }

        private static void AddSteamLibrary(string library, Action<string> add)
        {
            if (String.IsNullOrWhiteSpace(library)) return;
            add(Path.Combine(library, @"steamapps\common\Titanfall2"));
            string manifest = Path.Combine(library, @"steamapps\appmanifest_1237970.acf");
            if (!File.Exists(manifest)) return;
            Match m = Regex.Match(File.ReadAllText(manifest), "\"installdir\"\\s+\"([^\"]+)\"");
            if (m.Success) add(Path.Combine(library, "steamapps", "common", m.Groups[1].Value));
        }

        internal static bool IsAdministrator()
        {
            using (var id = WindowsIdentity.GetCurrent()) return new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator);
        }

        internal static string Quote(string value)
        {
            if (value.Contains("\"") || value.Contains("\r") || value.Contains("\n")) throw new ArgumentException("잘못된 경로입니다.");
            return "\"" + value.TrimEnd('\\') + "\"";
        }
    }

    internal sealed class InstallerForm : Form
    {
        private readonly ComboBox pathBox = new ComboBox();
        private readonly Button browse = new Button();
        private readonly Button install = new Button();
        private readonly Button restore = new Button();
        private readonly Label status = new Label();
        private readonly TextBox messages = new TextBox();
        private readonly ProgressBar progress = new ProgressBar();
        private bool busy;

        internal InstallerForm()
        {
            Text = "타이탄폴 2 VR 한글패치 — 제콜";
            Font = new Font("Malgun Gothic", 10F);
            ClientSize = new Size(640, 425);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            var title = new Label { Text = "타이탄폴 2 VR 한글패치 0.2.14", Left = 22, Top = 20, Width = 590, Height = 30, Font = new Font(Font.FontFamily, 16F, FontStyle.Bold) };
            var creator = new Label { Text = "유튜브 크리에이터 제콜 제작", Left = 24, Top = 58, Width = 570, Height = 24 };
            var label = new Label { Text = "타이탄폴 2 설치 폴더", Left = 24, Top = 99, Width = 550, Height = 23 };
            pathBox.SetBounds(24, 127, 484, 30);
            foreach (string path in Program.FindGames()) pathBox.Items.Add(path);
            if (pathBox.Items.Count > 0) pathBox.SelectedIndex = 0;
            browse.Text = "폴더 선택"; browse.SetBounds(520, 124, 96, 32);
            browse.Click += delegate {
                using (var dialog = new FolderBrowserDialog { Description = "Titanfall2.exe가 있는 폴더를 선택하세요.", ShowNewFolderButton = false })
                    if (dialog.ShowDialog(this) == DialogResult.OK) pathBox.Text = dialog.SelectedPath;
            };
            install.Text = "한글패치 설치"; install.SetBounds(24, 171, 284, 38);
            restore.Text = "원본으로 복구"; restore.SetBounds(320, 171, 296, 38);
            install.Click += async delegate { await Apply("Install", pathBox.Text); };
            restore.Click += async delegate { await Apply("Restore", pathBox.Text); };
            status.SetBounds(24, 222, 590, 26); status.Text = "타이탄폴 2 → VR 모드 → 한글패치 순서로 설치하세요.";
            progress.SetBounds(24, 211, 592, 7); progress.Visible = false; progress.Style = ProgressBarStyle.Marquee;
            messages.SetBounds(24, 255, 592, 145);
            messages.Multiline = true; messages.ReadOnly = true;
            messages.ScrollBars = ScrollBars.Vertical;
            messages.BackColor = SystemColors.Window;
            messages.Text = "현재 한글패치는 VR 모드 1.0.12까지 설치·제거가 확인되었습니다.\r\nVR 모드 버전이 이보다 높다면 일부 문제가 생길 수 있습니다.\r\n게임 내 동작은 추가 확인이 필요합니다.";
            Controls.AddRange(new Control[] { title, creator, label, pathBox, browse, install, restore, status, progress, messages });
            FormClosing += delegate(object sender, FormClosingEventArgs e) { if (busy) e.Cancel = true; };
        }

        internal async Task Apply(string action, string gamePath)
        {
            if (busy) return;
            try
            {
                if (!Program.IsGame(gamePath)) throw new IOException("Titanfall2.exe가 있는 게임 설치 폴더를 선택하세요.");
                gamePath = Path.GetFullPath(gamePath);
                if (!File.Exists(Path.Combine(gamePath, "Titanfall2VRLauncher.exe")) || !File.Exists(Path.Combine(gamePath, @".circuitlord-vr-mods\Titanfall2VR.json")))
                    throw new IOException("VR 모드를 먼저 설치해 주세요.");
                if (Process.GetProcessesByName("Titanfall2").Length > 0 || Process.GetProcessesByName("Titanfall2VRLauncher").Length > 0)
                    throw new IOException("게임을 종료한 뒤 다시 실행해 주세요.");
                if (!Program.IsAdministrator())
                {
                    var info = new ProcessStartInfo(Application.ExecutablePath, "--apply " + action + " " + Program.Quote(gamePath)) { UseShellExecute = true, Verb = "runas" };
                    Process.Start(info);
                    Close();
                    return;
                }
                pathBox.Text = gamePath;
                busy = true; install.Enabled = restore.Enabled = browse.Enabled = pathBox.Enabled = false; progress.Visible = true;
                status.Text = action == "Install" ? "한글패치를 설치하고 있습니다…" : "원본으로 복구하고 있습니다…";
                messages.Text = status.Text;
                string result = await Task.Run(delegate { return RunInstaller(action, gamePath); });
                status.Text = action == "Install" ? "설치 완료! VR 모드 설치기에서 게임을 실행하세요." : "원본으로 복구했습니다.";
                messages.Text = status.Text + "\r\n\r\n현재 한글패치는 VR 모드 1.0.12까지 설치·제거가 확인되었습니다.\r\nVR 모드 버전이 이보다 높다면 일부 문제가 생길 수 있습니다.\r\n게임 내 동작은 추가 확인이 필요합니다.";
            }
            catch (System.ComponentModel.Win32Exception ex)
            {
                status.Text = ex.NativeErrorCode == 1223 ? "관리자 권한 요청이 취소되었습니다." : ex.Message;
                messages.Text = status.Text;
            }
            catch (Exception ex) { status.Text = "완료하지 못했습니다."; messages.Text = ex.Message; }
            finally { busy = false; install.Enabled = restore.Enabled = browse.Enabled = pathBox.Enabled = true; progress.Visible = false; }
        }

        private static string RunInstaller(string action, string gamePath)
        {
            string tempRoot = Path.GetFullPath(Path.GetTempPath());
            string temp = Path.Combine(tempRoot, "Zecole-TF2VR-" + Guid.NewGuid().ToString("N"));
            try
            {
                Program.ExtractPayload(temp);
                string ps = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"WindowsPowerShell\v1.0\powershell.exe");
                var info = new ProcessStartInfo(ps, "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + Program.Quote(Path.Combine(temp, "Install.ps1")) + " -Action " + action + " -GameRoot " + Program.Quote(gamePath)) {
                    UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8
                };
                info.EnvironmentVariables["PSModulePath"] = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"WindowsPowerShell\v1.0\Modules");
                using (var process = Process.Start(info))
                {
                    Task<string> stdout = process.StandardOutput.ReadToEndAsync();
                    Task<string> stderr = process.StandardError.ReadToEndAsync();
                    process.WaitForExit(); Task.WaitAll(stdout, stderr);
                    string output = stdout.Result + stderr.Result;
                    if (process.ExitCode != 0) throw new IOException(output.Trim());
                    return output;
                }
            }
            finally
            {
                // Only the unique child created by this invocation can be removed.
                string full = Path.GetFullPath(temp);
                if (Path.GetDirectoryName(full).TrimEnd('\\').Equals(tempRoot.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase)
                    && Path.GetFileName(full).StartsWith("Zecole-TF2VR-", StringComparison.Ordinal) && Directory.Exists(full))
                    try { Directory.Delete(full, true); } catch { }
            }
        }
    }
}
