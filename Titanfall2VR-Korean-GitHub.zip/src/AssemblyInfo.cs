﻿using System.Reflection;
[assembly: AssemblyTitle("타이탄폴 2 VR 한글패치")]
[assembly: AssemblyDescription("유튜브 크리에이터 제콜 제작")]
[assembly: AssemblyCompany("ZECOLE")]
[assembly: AssemblyProduct("Titanfall 2 VR Korean Patch")]
[assembly: AssemblyVersion("0.2.14.0")]
[assembly: AssemblyFileVersion("0.2.14.0")]
