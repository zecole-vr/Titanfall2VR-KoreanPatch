using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Zecole.TitanfallKorean
{
    internal sealed class UpdateResult
    {
        internal string Message;
        internal bool Newer;
    }

    internal static class UpdateChecker
    {
        internal const string LatestPage = "https://github.com/zecole-vr/Titanfall2VR-KoreanPatch/releases/latest";
        internal const string Api = "https://api.github.com/repos/zecole-vr/Titanfall2VR-KoreanPatch/releases/latest";

        internal static Version ParseVersion(string tag)
        {
            if (String.IsNullOrEmpty(tag) || !System.Text.RegularExpressions.Regex.IsMatch(tag, @"\Av?\d+\.\d+\.\d+(\.\d+)?\z"))
                throw new FormatException();
            Version v = Version.Parse(tag.TrimStart('v'));
            return new Version(v.Major, v.Minor, v.Build, Math.Max(0, v.Revision));
        }

        internal static UpdateResult Parse(string json, Version current)
        {
            var data = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(json);
            if (data == null || !data.ContainsKey("draft") || !(data["draft"] is bool) || (bool)data["draft"] ||
                !data.ContainsKey("prerelease") || !(data["prerelease"] is bool) || (bool)data["prerelease"] ||
                !data.ContainsKey("tag_name") || !(data["tag_name"] is string)) throw new FormatException();
            Version latest = ParseVersion((string)data["tag_name"]);
            int comparison = latest.CompareTo(ParseVersion(current.ToString()));
            string version = latest.ToString(latest.Revision == 0 ? 3 : 4);
            return new UpdateResult {
                Newer = comparison > 0,
                Message = comparison > 0 ? "새 버전 v" + version + "이 있습니다. 최신 버전을 내려받으세요." :
                    comparison == 0 ? "최신 버전입니다. (GitHub v" + version + ")" :
                    "GitHub 최신 배포는 v" + version + "입니다. 이 설치기가 더 새 버전입니다."
            };
        }

        internal static async Task<UpdateResult> CheckAsync(Version current, HttpMessageHandler handler = null, TimeSpan? timeout = null)
        {
            try
            {
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                using (var client = handler == null ? new HttpClient() : new HttpClient(handler))
                {
                    client.Timeout = timeout ?? TimeSpan.FromSeconds(8);
                    client.MaxResponseContentBufferSize = 1024 * 1024;
                    client.DefaultRequestHeaders.UserAgent.ParseAdd("Zecole-Titanfall2VR-Korean-Installer/" + current);
                    client.DefaultRequestHeaders.Accept.ParseAdd("application/vnd.github+json");
                    using (var response = await client.GetAsync(Api).ConfigureAwait(false))
                    {
                        response.EnsureSuccessStatusCode();
                        return Parse(await response.Content.ReadAsStringAsync().ConfigureAwait(false), current);
                    }
                }
            }
            catch (Exception)
            {
                return new UpdateResult { Message = "최신 버전을 확인하지 못했습니다. 설치는 계속할 수 있습니다." };
            }
        }
    }
}
